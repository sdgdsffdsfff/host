var APP_ID = 'jnkkc4tJK771mnxHWRcEfT93-gzGzoHsz';
var APP_KEY = 'pzTlxET4siqJir92JJ90HybM';
AV.init({
  appId: APP_ID,
  appKey: APP_KEY
});
